/*
 * Copyright (c) 2004
 * Martin Woolley
 * All rights reserved.
 *
 */
package tests.exceptions;

public class SubmitSmFailedException extends Exception {
	public SubmitSmFailedException() {
		super();
	}

}
